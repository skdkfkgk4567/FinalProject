package greencamp.report.service;

import greencamp.report.model.ReportDTO;

public interface ReportService {
	
	public int Report(ReportDTO rdto);

}
