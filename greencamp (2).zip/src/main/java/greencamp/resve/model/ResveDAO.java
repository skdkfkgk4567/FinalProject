package greencamp.resve.model;

import java.util.List;

public interface ResveDAO {
public List<ResveVO> getlistresve(String id);
}
