package greencamp.like.model;

import java.util.List;

public interface LikeDAO {
	public int insertlikeuser(LikeDTO LikeDto); 
	public int deletelikeuser(int like_no);
	
	
		
	

}
