package greencamp.resve.model;

import java.util.List;

public interface ResveDAO {
public List<ResveDTO> getlistresve(String id);
}
